

/**
	QUAND JE CLIQUE SUR UN PARAGRAPHE => COLORE EN BLEU
**/

// Sélectionner le 1er paragraphe
 // sélectionner la DIV qui a la classe "container"
 let container = document.querySelectorAll('.container')


/**
	AFFICHER LA MODAL LORSQU'ON CLIQUE SUR UN PARAGRAPHE
**/

//  Sélectionner la modal et les paragraphes (OK)
let modal = document.querySelector('.modal')

//  Mettre un écouteur d'évènement (clic) sur les paragraphes = OK

for ( let h=0; h<container.length; h++) {
	for(let i=0; i<container[h].children.length; i++){
		// récupérer le paragraphe
		let para = container[h].children[i]
		// Mettre un écouteur d'évènement sur le paragraphe (clic)
		para.addEventListener('click',() => {

			//  Afficher la modal = passer la modal en display "flex"
			modal.style.display = "flex"

			/**
				RÉCUPÉRATION DU TEXTE A COLLER DANS LA MODAL
			**/
			//1- Sélection de la div avec la classe "modal-text" au sein du container sélectionné
			// (note : il n'y en a qu'une par "container")
			let div = container[h].querySelector('.modal-text')

			//2- Récupération du contenu de la div (on veut garder les balises)
			let divContent = div.innerHTML

			//3- Copie du contenu récupéré dans la "modal-content"
			let modalContent = document.querySelector('.modal-content')
			modalContent.innerHTML = divContent

			/**
				FAIRE DISPARAÎTRE LA MODAL SI ON CLIQUE SUR ELLE
			**/
			// 1- Sélectionner la modal (OK)
			// 2- Mettre un écouteur d'évènement (clic) sur la modal
			modal.addEventListener('click', () => {
				// 3- Faire disparaître la modal = passer en display "none" 
				modal.style.display = "none"
			})


		})
	}
}























